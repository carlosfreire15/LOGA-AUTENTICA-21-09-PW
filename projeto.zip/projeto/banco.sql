create database db_app_autenticacao;
use db_app_autenticacao;

create table tb_usuario(
	UsuarioID int auto_increment primary key,
    UsuNome varchar(100) not null unique,
    Login varchar(50) not null unique,
    Senha varchar(50) not null
);